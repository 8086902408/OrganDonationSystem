from django.urls import path
from .views import RecipientRegistrationView, RecipientLoginView, recipient_home


urlpatterns = [
    path('register/', RecipientRegistrationView.as_view(), name='rec_register'),
    path('login/', RecipientLoginView.as_view(), name='rec_login'),
    path('recipient_home/', recipient_home, name='recipient_home'),

]
