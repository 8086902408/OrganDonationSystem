from django.shortcuts import render
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.views.generic import View
from django.contrib.auth import authenticate, login
from django.contrib import messages

from donor_app.models import Donor, Request
from .models import Recipient
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse



class RecipientRegistrationView(View):
    def get(self, request):
        return render(request, 'recipient_reg.html')

    def post(self, request):
        email = request.POST.get('rd_email')
        password1 = request.POST.get('rpass1')
        password2 = request.POST.get('rpass2')
        phone_number = request.POST.get('rmobile')
        fname = request.POST.get('rfname')
        lname = request.POST.get('rlname')
        dob = request.POST.get('rbday')
        gender = request.POST.get('rinlineRadioOptions')
        username = email


        if password1 != password2:
            messages.error(request, 'Passwords do not match.')
            return render(request, 'recipient_reg.html')

        if User.objects.filter(email=email).exists():
            messages.error(request, 'Username is already taken..')
            return render(request, 'recipient_reg.html')

        user = User.objects.create_user(username=username, email=email, password=password1, first_name=fname, last_name=lname)
        recipient = Recipient.objects.create(user=user,
                                            phone_number=phone_number,
                                            dob=dob,
                                            first_name=fname,
                                            last_name=lname,
                                            gender=gender
                                            )
        messages.success(request, 'Registation succesful')

        return render(request, 'recipient_login.html')



class RecipientLoginView(View):
    def get(self, request):
        return render(request, 'recipient_login.html')

    def post(self, request):
        username = request.POST.get('remail')
        password = request.POST.get('rpass')

        print("RecipientLoginView called...",username, password)

        user = authenticate(request, username=username, password=password)
        print("user", user)
        if user is not None:
            try:
                recipient = user.recipient
                print("recipient",recipient)
            except Exception:
                messages.error(request, 'Invalid login credentials.')
                return render(request, 'recipient_login.html')
            if not recipient:
                messages.error(request, 'Invalid login credentials.')
                return render(request, 'recipient_login.html')
                
            login(request, user)
            return redirect('recipient_home')
        else:
            messages.error(request, 'Invalid login credentials.')
            return render(request, 'recipient_login.html')

@login_required
def recipient_home(request):
    try:
        recipient = request.user.recipient
    except Exception:
        messages.error(request, 'Invalid login credentials.')
        return render(request, 'recipient_login.html')
    
    if request.method == 'GET':
        # Get all list of Donors
        donors = Donor.objects.all()
        return render(request, 'rec_dash.html', {'donors': donors})
    elif request.method == 'POST':
        print("recipient_home called post")
        recipient = request.user.recipient
        donor_id = request.POST.get('don_id')

        print("got donor id backend: ", donor_id)
        if donor_id:
            donor = Donor.objects.get(id=donor_id)
            new_req = Request.objects.create(from_donor=donor, to_recipient=recipient)
            messages.success(request, 'Request sent successfully.')
        else:
            messages.error(request, 'Error in sending request.')

        return redirect('recipient_home')
    

            

