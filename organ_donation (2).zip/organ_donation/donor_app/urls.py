from django.urls import path
from .views import donor_reg_view, donor_login_view, donor_dashboard


urlpatterns = [
    path('donor_reg/', donor_reg_view, name='donor_reg'),
    path('donor_login/', donor_login_view, name='donor_login'),
    path('donor_dashboard/', donor_dashboard, name='donor_dashboard'),




]
