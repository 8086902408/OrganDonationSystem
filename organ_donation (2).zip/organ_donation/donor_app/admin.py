from django.contrib import admin
from .models import Request, Donor

admin.site.register(Donor)
admin.site.register(Request)
