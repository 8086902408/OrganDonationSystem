from django.db import models
from django.contrib.auth.models import User
from recipient_app.models import Recipient

class Donor(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='donor')
    phone_number = models.CharField(max_length=20, null=True)
    first_name = models.CharField(max_length=100, null=True)
    last_name = models.CharField(max_length=100, null=True)
    dob = models.CharField(max_length=100, null=True)
    gender = models.CharField(max_length=20, null=True)
    organs = models.CharField(max_length=255)
    additional_info = models.TextField(blank=True)
    consent_letter = models.FileField(upload_to='consent_letters/')

    def __str__(self):
        return self.user.username

    class Meta:
        db_table = "Donors"


class Request(models.Model):
    from_donor  = models.ForeignKey(Donor, on_delete=models.CASCADE, related_name='donor_requests')
    to_recipient = models.ForeignKey(Recipient, on_delete=models.CASCADE, related_name='recipient_requests')
    request_date = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=10, choices=[('pending', 'Pending'), ('accepted', 'Accepted'), ('rejected', 'Rejected')], default='pending')
    
    def __str__(self):
        return f"Request from {self.to_recipient.user.username} to {self.from_donor.user.username}"
    
    class Meta:
        db_table = "Requests"

