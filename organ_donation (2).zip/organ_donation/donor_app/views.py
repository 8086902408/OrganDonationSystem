from django.shortcuts import render
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required

from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from donor_app.models import Donor, Request

# Create your views here.


def donor_reg_view(request):
    if request.method == "GET":
        return render(request, "donor_reg.html")
    elif request.method == 'POST':

        print("donor_reg_view called.....")
        # Extract form data
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        bday = request.POST.get('bday')
        gender = request.POST.get('inlineRadioOptions')
        email = request.POST.get('d_email')
        mobile = request.POST.get('mobile')
        pass1 = request.POST.get('pass1')
        pass2 = request.POST.get('pass2')
        organs = request.POST.get('org')

        cons_file = request.FILES.get('c_file')
        print(cons_file)

        # Perform validation
        if pass1 != pass2:
            messages.error(request, 'Passwords do not match')
            return render(request, 'donor_reg.html')
        

        if User.objects.filter(email=email).exists():
            messages.error(request, 'Username is already taken.')
            return render(request, 'donor_reg.html')
        
        # Create user
        try:
            user = User.objects.create_user(username=email, email=email, password=pass1,
                                        first_name=fname, last_name=lname)
        except Exception:
            messages.error(request, 'Something wroong with user details. please check')
            return render(request, 'donor_reg.html')
        
        print("user obeject created", user)

        
        # Create Donor object
        try:
            donor = Donor.objects.create(user=user,
                                        phone_number=mobile,
                                        dob=bday,
                                        first_name=fname,
                                        last_name=lname,
                                        gender=gender,
                                        organs= organs,
                                        consent_letter=cons_file
                                        )
        except Exception:
            messages.error(request, 'Something wroong with donor details. please check')
            return render(request, 'donor_reg.html')
        
        print("donor obeject created", donor)

        # Redirect to success page
        messages.success(request, 'Registration successful')
        return redirect('donor_login')
    


def donor_login_view(request):
    if request.method == 'POST':
        username = request.POST.get('d_email')
        password = request.POST.get('d_password')
        print("donor_login_view", username, password)

        user = authenticate(request, username=username, password=password)
        print(user)
        if user is not None:
            login(request, user)
            return redirect('donor_dashboard')
        else:
            messages.error(request,"Invalid credentials for Donor")
            return render(request, 'donorlogin.html')
    else:
        return render(request, 'donorlogin.html')
    
@login_required
def donor_dashboard(request):
    try:
        if not request.user.donor:
            return redirect('home')
    except Exception:
        return redirect("home")

    if request.method == 'GET':
        print("get request called ", request.user.donor.pk)
        rec_status = "Not Assigned to anyone"
        donor = Donor.objects.get(pk=request.user.donor.pk)
        got_recipient = Request.objects.filter(from_donor=donor, status='accepted').first()
        print("got_recipient", got_recipient)
        if got_recipient:
            rec_status = f'Assigned to {got_recipient.to_recipient.user.username}'

        # Get all requests for this donor from Request model
        reqs = Request.objects.filter(from_donor=request.user.donor, status= "pending")


        print(reqs, rec_status)
        return render(request, 'donor_dash.html',{'reqs':reqs, 'rec_status': rec_status})
    elif request.method == 'POST':
        print("post called accept req r rej")
        req_id = request.POST.get('req_id')
        action = request.POST.get('action')

        if req_id and action:
            req = Request.objects.get(id=req_id)

            if action == 'accept':
                req.status = 'accepted'
                req.save()

            elif action == 'reject':
                req.status = 'rejected'
                req.save()

    return redirect('donor_dashboard')


