from django.db import models
from django.contrib.auth.models import User

class Doctor(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='doctor')
    specialization = models.CharField(max_length=100, null=True)
    experience_years = models.PositiveIntegerField(null=True)
    phone_number = models.CharField(max_length=20, null=True)
    address = models.CharField(max_length=200, null=True)

    def __str__(self):
        return self.user.username
    
    class Meta:
        db_table = "Doctors"
