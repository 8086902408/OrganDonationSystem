from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib import messages
from donor_app.models import Donor

from recipient_app.models import Recipient

def doctor_login(request):
    if request.user.is_authenticated:
        logout(request)

    if request.method == 'POST':
        print("Post req recieved")
        email = request.POST.get('doc_mail')

        password = request.POST.get('doc_pass')

        user = authenticate(username=email, password=password)
        if not user:
            messages.error(request, 'Invalid login credentials for doctor!')
            return render(request, 'doc_login.html')

        try:
            if user is not None and user.is_staff and user.doctor:
                login(request, user)
                return redirect('doctor_dashboard')
            else:
                messages.error(request, 'Invalid login credentials for doctor!')
        except Exception:
            messages.error(request, 'Invalid login credentials for doctor!')


    return render(request, 'doc_login.html')


@login_required
def doctor_dashboard(request):
    if request.user.is_authenticated and request.user.is_staff:
        recs = Recipient.objects.all()
        donors = Donor.objects.all()
        return render(request, 'doctor_dashboard.html', {'recs':recs, 'donors':donors})
    else:

        return HttpResponse("You are not authorized to access this page.")
